package lectures.core.autowired;

import lectures.core.AutoAppConfig;
import lectures.core.discount.DiscountPolicy;
import lectures.core.member.Grade;
import lectures.core.member.Member;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;
import java.util.Map;
import static org.assertj.core.api.Assertions.assertThat;

public class AllBeanTest {

    @Test
    void findAllBean() {
        ApplicationContext ac = new AnnotationConfigApplicationContext(AutoAppConfig.class, DiscountService.class);
        DiscountService discountService = ac.getBean(DiscountService.class);
        Member member = new Member(1L, "userA", Grade.VIP);

        int discountPrice = discountService.discount(member, 20000,"fixDiscountPolicy");
        System.out.println("findAllBean.discountPrice = " + discountPrice);;

        assertThat(discountService).isInstanceOf(DiscountService.class);
        assertThat(discountPrice).isEqualTo(1000);
    }

    static class DiscountService {
        private final Map<String, DiscountPolicy> policyMap;
        private final List<DiscountPolicy> policies;

        public DiscountService(Map<String, DiscountPolicy> policyMap, List<DiscountPolicy> policies) {
            this.policyMap = policyMap;
            this.policies = policies;

            System.out.println("DiscountService.policyMap = " + policyMap);
            System.out.println("DiscountService.policies = " + policies);
        }

        public int discount(Member member, int price, String discountCode) {
            DiscountPolicy discountPolicy = policyMap.get(discountCode);

            System.out.println("DiscountService.discount.discountCode  =" + discountCode);
            System.out.println("DiscountService.discount.discountPolicy=" + discountPolicy);

            return discountPolicy.discount(member, price);
        }
    }
}
