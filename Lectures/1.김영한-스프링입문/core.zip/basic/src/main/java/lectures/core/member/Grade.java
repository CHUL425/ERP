package lectures.core.member;

public enum Grade {
    BASIC,
    VIP
}
