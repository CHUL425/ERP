package lectures.core.order;

import lectures.core.annotataion.MainDiscountPolicy;
import lectures.core.discount.DiscountPolicy;
import lectures.core.discount.FixDiscountPolicy;
import lectures.core.discount.RateDiscountPolicy;
import lectures.core.member.Member;
import lectures.core.member.MemberRepository;
import lectures.core.member.MemoryMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class OrderServiceImpl implements OrderService {
    private final MemberRepository memberRepository;
    private final DiscountPolicy   discountPolicy  ;

    @Autowired
    public OrderServiceImpl(MemberRepository memberRepository, @Qualifier("mainDiscountPolicy") DiscountPolicy discountPolicy) {
        System.out.println("OrderServiceImpl.memberRepository=" + memberRepository);
        System.out.println("OrderServiceImpl.discountPolicy  =" + discountPolicy  );

        this.memberRepository = memberRepository;
        this.discountPolicy   = discountPolicy  ;
    }

    @Override
    public Order createOrder(Long memberId, String itemName, int itemPrice) {
        Member member = memberRepository.findById(memberId);

        int discountPrice = discountPolicy.discount(member, itemPrice);

        return new Order(memberId, itemName, itemPrice, discountPrice);
    }

    //테스트 용도
    public MemberRepository getMemberRepository() {
        return memberRepository;
    }
}
