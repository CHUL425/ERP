package lectures.core;

import lectures.core.member.Grade;
import lectures.core.member.Member;
import lectures.core.member.MemberService;
import lectures.core.member.MemberServiceImpl;
import lectures.core.order.Order;
import lectures.core.order.OrderService;
import lectures.core.order.OrderServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class OrderApp {
    public static void main(String[] args) {
//        AppConfig appConfig = new AppConfig();
//        MemberService memberService = appConfig.memberService();
//        OrderService orderService = appConfig.orderService();
        ApplicationContext acapplicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService = acapplicationContext.getBean("memberService", MemberService.class);
        OrderService orderService = acapplicationContext.getBean("orderService", OrderService.class);

        long memberId = 1L;

        Member member = new Member(1L, "memberA", Grade.VIP);
        memberService.join(member);

        Order order = orderService.createOrder(memberId, "itemA", 10000);

        System.out.println("order = " + order);
        System.out.println("order.calculatePrice = " + order.calculatePrice());

    }
}